package com.pedro.bibliotecaApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
